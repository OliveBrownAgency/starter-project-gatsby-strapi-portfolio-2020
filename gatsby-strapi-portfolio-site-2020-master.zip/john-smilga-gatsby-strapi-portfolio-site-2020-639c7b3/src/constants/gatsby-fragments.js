// ...GatsbyImageSharpFluid
